PHỐ ẨM THỰC · Vietnamese Food Street · Playtest 01
Prototype 0.8.1

Play: https://hminnxinhh.github.io/phoamthuc-demo/preview/
Info: https://hminnxinhh.github.io/phoamthuc-demo/playtest/

These are actual screenshots and a 20-second gameplay clip at real speed.
Portrait MP4: original 390x844; TikTok file: same clip fitted inside 1080x1920 without cropping, retiming, or added music.
VI/EN text is provided for introducing this prototype. The package itself does not post or publish to social accounts.

You may use these assets to introduce/playtest Phố Ẩm Thực with the game name and play link. Do not resell the assets or present them as a different game. Development repository, account access, internal reports and player saves are not included.

No in-game ads, payments or account. Browser-local progress. Export/import in the game Menu when changing devices or sites.
